const mongoose = require('mongoose');
// mongoose.connect("mongodb://127.0.0.1:27017/above_scripter");
mongoose.connect("mongodb+srv://pyash4048:xKCHPjodChb14gpZ@mainhackprac.s6k4eri.mongodb.net/above_scripter")
.then(()=>{
  console.log("connection established successfully by mongodb");
})
.catch((error=>{
  console.log("error occured");
  console.log(error);
}));
const plm = require('passport-local-mongoose');

let userschema = mongoose.Schema({
  username:{
    type:String,
    required:true
  },
  email : {
    type: String,
    required : true
  },
  password : {
    type:String,
  },
  enrolled_path:[{
    type:mongoose.Schema.Types.ObjectId,
    ref: 'paths'
  }]
  ,
  profile_image : {
    type : String,
    default : "/images/footer-img.png"
  },
  machienes_done : {
    type : Array,
    default : []
  },
  selected_path : String,
  premimum : {
    type : Boolean,
    default : false
  },
  modules_done : {
    type : Array,
    default : []
  },
  sectiondone:[{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'modules.section._id'
  }],
  created_at : {
    type:Date,
    default : Date.now()
  }
});

userschema.plugin(plm);
module.exports = mongoose.model('users',userschema);