let mongoose = require('mongoose');
let pathschema = mongoose.Schema({
    pathname:{
        type:String,
        required:true,
    },
    pathtype:String,
    image:String,
    title:{
        type:String,
        required : true,
    },
    discription:{
        type:String,
    },
    parts:[{
        part_name:String,
        part_discription:String,
        part_image:String,
        modules:[{
            type:mongoose.Schema.Types.ObjectId,
            ref:'modules',
        }]
    }],
    level:String,

});

module.exports = mongoose.model('paths',pathschema);