var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
  res.render('index');
});

router.get('/task3',function(req,res){
  res.render('uname',{message:"",title:"task3"});
})

router.get('/task2',function(req,res){
  res.render('uname',{message:"",title:"task2"});
})

router.get('/task1',function(req,res){
  res.render('uname',{message:"",title:"task1"});
})



router.post('/task1',function(req,res){
  let username = req.body.username;
  let password = req.body.password;
  if(username == "lewis" || username =='martin' || username =='parker' || username =='cooper'){
    return res.status(302).render('uname',{message:"Invalid username or Password",title:"task1"});
  };
  res.status(200).render('uname',{message:"Invalid username or Password",title:"task1"});
});

router.post('/task2',function(req,res){
  let username = req.body.username;
  let password = req.body.password;
  if(username == "patterson" || username =='jackson'){
    setTimeout(()=>{
      return res.render('uname',{message:"Invalid username or Password",title:"task2"});
    },700);
  };
  res.render('uname',{message:"Invalid username or Password",title:"task2"});
});

router.post('/task3',function(req,res){
  let username = req.body.username;
  let password = req.body.password;
  if(username == "admin" || username == "phillips"){
    return res.status(200).render('uname',{message:"Invalid Password", title:"task3"});
  };
  res.status(200).render('uname',{message:"Invalid Username", title:"task3"});
});

module.exports = router;
