let mongoose = require('mongoose');
mongoose.connect('mongodb+srv://pyash4048:AJZf0xdpWTfzDern@hackprac.oxrdo9t.mongodb.net/hackprac')
.then(()=>{
  console.log("connection established successfully by mongodb");
})
.catch((error=>{
  console.log("error occured");
  console.log(error);
}))

let ctfschema = mongoose.Schema({
  name : String,
  image:String,
  discription:String,
  flag:String,
  link:String,
  type:String,
  lev:String,
}); 

module.exports = mongoose.model('challenge',ctfschema);