let mongoose = require('mongoose');
let currentctf = mongoose.Schema({
    ctfname:String,
    sol:{
        type:Array,
        default:[],
    },
    challanges:String,
    participants:[{
        uname:String,
        upass:String,   
        score:Number,
        solved:[{
            type:String,
        }]
    }]
})

module.exports = mongoose.model('currentctf',currentctf);