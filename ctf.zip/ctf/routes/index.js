var express = require('express');
let challmodel = require('./users');
var router = express.Router();
let currentctf = require('./currentctf');
const users = require('./users');
const { name } = require('ejs');

router.get('/', function(req, res, next) {
  res.send('Welcome ');
});

router.get('/hack/:ctfname/challenges/',isloggedin,async function(req,res){
  // console.log(req.params.ctfname);
  let ctf = await currentctf.findOne({ctfname:req.params.ctfname});
  let chall = ctf.challanges.split(',');
  let challd = [];
  for(let i=0;i<chall.length;i++){
    let a =await challmodel.findOne({name:chall[i]});
    if(a){   
      await challd.push(a);
    };
  }
  // console.log(challd);
  
  if (ctf){
    let user = ctf.participants.find(participant => participant.uname === uname);
    if(user){
      return res.render('challanges',{ctf,user,challd});
    }
    else{
      res.render('error');
    }
  }
  else{
    res.render('error');
  }
})

router.post('/createctf',async function(req,res){
  let name = req.body.name;
  let uparray = "";
  req.body.challenges.forEach((e)=>{
        uparray+=e+","
    })
  let challenges = uparray.slice(0,-1);
  let ctf = new currentctf({
    ctfname:name,
    challanges:challenges,
    participants:[],
  });
  for(let i=0;i<req.body.challenges.length;i++){
    await ctf.sol.push(0);
    console.log(req.body.challenges[i]);
  };
  await ctf.save();
  res.json({"cat":`http://localhost/hack/${name}`});
});

router.get('/hack/:ctfname',async function(req,res){
  let ctf = await currentctf.findOne({ctfname:req.params.ctfname});
  uname = req.session.user
  if (ctf){
    let user = ctf.participants.find(participant => participant.uname === uname);
    console.log('Found participant:', user);
    return res.render('home',{ctf,user});
  }
  res.render('home',{ctf,user:null});
})

router.get('/hack/:ctfname/login',async function(req,res){
  let ctf = await currentctf.findOne({ctfname:req.params.ctfname});
  res.render('login',{ctf});
})

router.post('/hack/:ctfname/challenges/checkans',async function(req,res){
  // let user = await user
  let ctf = await currentctf.findOne({ctfname : req.params.ctfname});
  if(ctf){
    console.log(req.body.chalname);
    let challenge = await challmodel.findOne({name:req.body.chalname});
    let user = ctf.participants.find(participants => participants.uname === req.session.user);
    if(challenge.flag == req.body.chalflag){
      user.score += 30;
      await user.solved.push(challenge.name);
      return res.json({mes:"yes"});
    }
    return res.json({mes:"no"});  
  }
  res.json({mes:"no"});
});

router.post('/hack/:ctfname/login',async function(req,res){
  let ctf = await currentctf.findOne({ctfname:req.params.ctfname});
  console.log(req.body.name);
  let user = ctf.participants.find(participants => participants.uname === req.body.name);
  if(user){
    if(user.uname == req.body.pass)
    {
      req.session.user = user.uname;
      return res.redirect(`/hack/${ctf.ctfname}/`)
    }
    else{
      return res.redirect(`/hack/${ctf.ctfname}/login`);
    }
  }
  
  console.log('error in code');
  res.render('login',{ctf});
})

router.post('/hack/:ctfname/register',async function(req,res){
  let ctf = await currentctf.findOne({ctfname:req.params.ctfname});
  if (ctf) {
    await ctf.participants.push({
      uname: req.body.uname,
      upass: req.body.pass,
      score: 0,
    });
    await ctf.save();
    req.session.user=req.body.uname;
    return res.redirect(`/hack/${ctf.ctfname}`);
  } else {
    return res.redirect('register');
  }
});

router.get('/hack/:ctfname/register',async function(req,res){
  let ctf = await currentctf.findOne({ctfname:req.params.ctfname});
  res.render('registration',{ctf});
})

router.get('/addchallenge',function(req,res){
  res.render('addchallenge');
})

router.post('/addchallenge', async function(req, res) {

  let challenge = new challmodel({
    name: req.body.name,
    discription: req.body.discription,
    image: req.body.image,
    flag: req.body.flag,
    link: req.body.link,
    lev: req.body.level, 
    type: req.body.type,
  });
  await challenge.save();
  res.send("done");
});

function isloggedin (req,res,next)
{
  if (req.session.user) return next();
  console.log(req.path);
  res.redirect('/hack/thrusty/login');
}


module.exports = router;
