const { json, response } = require("express");

var originalBackgroundImage; // Variable to store the original background image URL

function openTask(title, description, link,i) {
    var modal = document.getElementById(`modal${i}`);
    var titleElement = document.getElementById("task-title");
    var descriptionElement = document.getElementById("task-description");
    var linkElement = document.getElementById("task-link");

    titleElement.textContent = title;
    descriptionElement.textContent = description;
    linkElement.href = link;

    // Store the original background image URL
    originalBackgroundImage = document.body.style.backgroundImage;

    modal.style.display = "block";
    document.body.style.backgroundImage = "none"; // Set background image to none to show the modal clearly
}

function closeModal(i) {
    var modal = document.getElementById(`modal${i}`);
    modal.style.display = "none";

    // Restore the original background image URL
    document.body.style.backgroundImage = originalBackgroundImage;
}

function submitFlag(name,i) {
    console.log(i);
    var flag = document.getElementById(`flag-input${i}`).value;
    // var name = document.getElementById(``).innerHTML;
    let data = {  // Define data object
        chalflag: flag,
        chalname: name,
    };
    console.log(data);
    let path = window.location.pathname + '/checkans';
    
    fetch(path, {
        method: 'POST',
        headers: {
            'Content-type': 'application/json'
        },
        body: JSON.stringify(data)  // Set the request body
    })
    .then((response) => {
        return response.json();
    })
    .then((response) => {
        if(response.mes == 'yes'){
            let sol = document.getElementById(`solves${i}`);
            let p = parseInt(sol.innerHTML);
            p++;
            sol.innerHTML=p.toString();
            closeModal(i);
            

        }
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}
